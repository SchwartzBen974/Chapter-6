package ProgramTwo;

public class BankAccount {
    private double balance;
    private String name;

    public BankAccount() {

    }

    public BankAccount(String n, double dBal) {

    }
    
    public BankAccount(String n, int iBal) {

    }

    public String getName() {
        return name;
    }

    public double getBalance() {
        return balance;
    }

    public void setName(String n) {
        name = n;
    }

    public void setBalance(double b) {
        balance = b;
    }

    public void setBalance(int i) {
        balance = i;
    }

    public void Withdraw(double amt) {
        balance = balance - amt;
    }

    public void Deposit(double amt) {
        balance = balance + amt;
    }

}
