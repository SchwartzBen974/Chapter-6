package vehicle;

import java.util.Scanner;

public class VehicleMAIN {
    
    public static void main(String[] args) {
        VehicleCLASS ford = new VehicleCLASS("F150");
        Scanner keybd = new Scanner(System.in);
        
        SOPl(ford.getYear() + "");
        SOPl("Enter a new year: ");
        ford.setYear(keybd.nextInt());
        SOPl(ford.getYear() + "");

        


        keybd.close();
    }

    public static void SOPl(String str) {
        System.out.println(str);
    }

}