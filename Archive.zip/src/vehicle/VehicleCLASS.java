package vehicle;

public class VehicleCLASS {
    private int year;
    private String model;
    public int mileage;


    //Constructor
    public VehicleCLASS(String modelType) {
        model = modelType;
        year = 1900;
    }


    public String getModel() {
        return model;
    }

    public void setYear(int yr) {
        year = yr;
    }

    public int getYear() {
        return year;
    }

}