package Dice;

public class MDice {
    
    public static void main(String[] args) {
        Die d1 = new Die();
        Die d2 = new Die(12);

        System.out.println("New Roll " + d1.getRoll());
    }

}
