package Dice;

import java.util.Random;

public class Die {
    Random Randomizer = new Random();
    
    private int sides = 6;

    //-Constructors----------------------------//
    public Die() {
        rollDie();

    }

    public Die(int s) {
        sides = s;
        rollDie();
    }

    public int getRoll() {
        return Randomizer.nextInt(sides) + 1;
    }

    public void rollDie() {
        for (int i = 0; i < 50; i++) {
            System.out.println(getRoll());
        }
    }
}
