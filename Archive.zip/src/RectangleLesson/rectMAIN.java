package RectangleLesson;

public class rectMAIN {
    
    public static void main(String[] args) {

        //-Create-Objects----------------------//
        //-r1----------------------------------//
        Rectangle r1 = new Rectangle();
        //-r1-//
        //-r2----------------------------------//
        Rectangle r2 = new Rectangle(20, 10);
        //-r2-//
        //-C-O-//

        //-Set-Values--------------------------//
        r1.setBase(5.0);
        r1.setHeight(10.0);
        //-S-V-//
 
        System.out.println(r1);
        System.out.println(r2);

    }
}
