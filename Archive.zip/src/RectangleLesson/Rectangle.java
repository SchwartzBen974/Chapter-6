package RectangleLesson;

public class Rectangle {

    private double b, h, area, perimeter;

    //-Constructor-----------------------------//
    public Rectangle() {

    }
    //-C-//

    //-Overload--------------------------------//
    public Rectangle(double base, double height) {
        b = base;
        h = height;
    }
    //-O-//

    //-Setters-&-Getters-----------------------//
    //-Base------------------------------------//
    public void setBase(double base) {
        b = base;
    }
    public double getBase() {
        return b;
    }
    //-B-//
    //-Height----------------------------------//
    public void setHeight(double height) {
        h = height;
    }
    public double getHeight() {
        return h;
    }
    //-H-//
    //-S-&-G-//
    
    //-Calculators-----------------------------//
    //-Area------------------------------------//
    public double area() {
        area = b * h;
        return area;
    }
    //-A-//
    //-Perimeter-------------------------------//
    public double perimeter() {
        perimeter = 2 * (b + h);
        return perimeter;
    }
    //-P-//
    //-C-//

    public String toString() {
        area();
        perimeter();
        String str = "Rectangle Data: " 
            + "\nBase: " + b
            + "\nHeight: " + h
            + "\nArea: " + area
            + "\nPerimeter: " + perimeter
            + "\n";

        return str;
    }

}