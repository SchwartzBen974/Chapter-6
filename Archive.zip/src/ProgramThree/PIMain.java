package ProgramThree;

import java.util.Scanner;

public class PIMain {

    static Scanner keybd = new Scanner(System.in);
    
    public static void main(String[] args) {
        PersonalInfo p1 = new PersonalInfo("Ben Schwartz", "PA", "Stewartstown", "Orchard Rd.", 3970, 17, "(717)-377-4947");
        PersonalInfo p2 = new PersonalInfo("Steven Schwartz", "PA", "Stewartstown", "Orchard Rd.", 3970, 62, "(703)-980-4969");
        PersonalInfo p3 = new PersonalInfo("Susan Schwartz", "PA", "Stewartstown", "Orchard Rd.", 3970, 55, "(717)-887-9676");
        SOPl(p1.toString());
        SOPl(p2.toString());
        SOPl(p3.toString());
    }

    public static void SOPl(String str) {
        System.out.println(str);
    }
}
