package ProgramThree;

public class PersonalInfo {
    
    private String name;
    private String stAddress;
    private String city;
    private String state;
    private String address;
    private int houseNumber;
    private int age;
    private String telNumber;

    //-Constructor-----------------------------//
    public PersonalInfo() {

    }
    //-----------------------------Constructor-//
    //
    //-Overload--------------------------------//
    public PersonalInfo(String n, String stt, String c, String st, int hNum, int a, String tel) {
        name = n;
        address = CreateAddress(stt, c, st, hNum);
        age = a;
        telNumber = tel;
    }
    //-------------------------------Overloads-//
    //
    //-Doers-----------------------------------//
    public String CreateAddress(String sta, String cit, String str, int num) {
        String tmp = "" + num + " " + str + ", " + cit + ", " + sta;
        return tmp;
    }

    public void UpdateAddress(String sta, String cit, String str, int num) {
        address = "" + num + " " + str + ", " + cit + ", " + sta;
    }
    //-----------------------------------Doers-//
    //
    //-Sets------------------------------------//
    public void setName(String str) {
        name = str;
    }

    public void setHouseNumber(int num) {
        houseNumber = num;
        UpdateAddress(state, city, stAddress, houseNumber);
    }
    
    public void setStreetAddress(String str) {
        stAddress = str;
        UpdateAddress(state, city, stAddress, houseNumber);
    }

    public void setCity(String str) {
        city = str;
        UpdateAddress(state, city, stAddress, houseNumber);
    }

    public void setState(String str) {
        state = str;
        UpdateAddress(state, city, stAddress, houseNumber);
    }

    public void setAge(int num) {
        age = num;
    }

    public void setTelNumber(String num) {
        telNumber = num;
    }
    //------------------------------------Sets-//
    //
    //-Gets------------------------------------//
    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getState() {
        return state;
    }

    public String getCity() {
        return city;
    }

    public String getStreetAddress() {
        return stAddress;
    }

    public int getHouseNumber() {
        return houseNumber;
    }

    public int getAge() {
        return age;
    }

    public String getTelNumber() {
        return telNumber;
    }
    //------------------------------------Gets-//

    public String toString() {
        String str = "______________" 
            + "\nPersonal Info: "
            + "\nName: " + name
            + "\nAddress: " + address
            + "\nAge: " + age
            + "\nTelephone #:" + telNumber
            + "\n ";
        return str;
    }
}
