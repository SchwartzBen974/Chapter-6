package ProgramTwelve;

public class CoinToss {
    
    public static void main(String[] args) {
        Coin c = new Coin();
        SOPl(c.getSideUp());    
    }

    public static void SOPl(String str) {
        System.out.println(str);
    }

}
