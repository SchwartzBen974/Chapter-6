package ProgramOne;

public class EmployeeClass {
    
    private String name;
    private int idNumber;
    private String department;
    private String position;

    //---Constructors--------------------------//
    //-Basic-----------------------------------//
    public EmployeeClass() {
        name = "";
        idNumber = 0;
        department = "";
        position = "";
    }
    //-B-//
    //-2---------------------------------------//
    public EmployeeClass(String n, int num) {
        name = n;
        idNumber = num;
        department = "";
        position = "";
    }
    //-2-//
    //-4---------------------------------------//
    public EmployeeClass(String n, int num, String dep, String pos) {
        name = n;
        idNumber = num;
        department = dep;
        position = pos;
    }
    //-4-//
    //-C-//

    //-Setters-&-Getters-----------------------//
    //-Sets------------------------------------//
    public void setName(String str) {
        name = str;
    }
    ////
    public void setIdNumber(int num) {
        idNumber = num;
    }
    ////
    public void setDepartment(String str) {
        department = str;
    }
    /////
    public void setPosition(String str) {
        position = str;
    }
    //-S-//
    //-Gets------------------------------------//
    public String getName() {
        return name;
    }
    ////
    public int getIdNumber() {
        return idNumber;
    }
    ////
    public String getDepartment() {
        return department;
    }
    ////
    public String getPosition() {
        return position;
    }
}
